﻿namespace Biblioteca
{
    public static class globals
    {
        public static string tipoUtente;
        public static string nomeUtente;

        public static System.Windows.Forms.DataGridView DATAGRID;
        public static System.Windows.Forms.ComboBox COMBO;
    }
}
