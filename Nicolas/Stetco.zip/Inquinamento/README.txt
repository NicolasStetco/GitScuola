Prof stavo dando un ultima controllata al progetto quando per sbaglio ho cancellato una tabella dal DB,
faccio per sostituire il .mdf con uno "nuovo preso dall'esercizio zippato su classroom ma continua a darmi errore.
Spero che a lei non causi questo problema....
Buona giornata.